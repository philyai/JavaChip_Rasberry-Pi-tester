# Raspberry Pi 4B Hardware Tester

A safe, native PySide6 desktop diagnostic application for **Raspberry Pi 4 Model B** running **Raspberry Pi OS 64-bit** or **Debian 64-bit**. It is intentionally Pi-4B-focused and does not present other machines as fully supported.

The application runs read-only checks and clearly separates six outcomes:

- `PASS`: the named safe check observed the stated condition.
- `WARNING`: the check found something that deserves review.
- `FAIL`: the check found a threshold breach, such as unsafe CPU temperature or critically full root storage.
- `MANUAL TEST REQUIRED`: a safe software check cannot establish hardware health.
- `NOT AVAILABLE`: the required interface, command, permission, or connected hardware was unavailable.
- `NOT TESTED`: no result has been collected yet.

`PASS` does not mean every part of the board is proven fault-free. The saved report preserves the exact evidence collected for each check.

## What it checks

Quick Test covers the requested Pi model, OS, CPU/CPU load/frequency/temperature, RAM availability and limits of basic RAM health information, root filesystem and microSD inventory, firmware power/throttle flags, Wi-Fi, Ethernet, Bluetooth, USB, and recent error-level kernel messages.

Full Hardware Test adds safe availability checks for GPIO, I2C, SPI, UART, and the supported Pi camera utilities. It does not stress CPU or RAM, change system configuration, write to a disk/device, connect to networks, or run destructive tests.

The **Manual Hardware Tests** screen provides safe instructions for USB ports, Ethernet traffic, both HDMI ports, audio, CSI camera connector, GPIO header, wireless range, and cooling under the real robotics workload.

## Install on Raspberry Pi OS or Debian 64-bit

On the Pi, copy this whole folder and run:

```bash
cd /path/to/Rasberry\ pi\ tester
sudo apt update
sudo apt install -y python3-pyside6 python3-psutil python3-serial iw usbutils bluez
sudo apt install -y libcamera-apps || sudo apt install -y rpicam-apps
python3 app.py
```

On newer Raspberry Pi OS releases, the camera package/command may be named `rpicam-apps` and `rpicam-hello`; the application supports both `libcamera-hello` and `rpicam-hello` when installed.

If your image does not provide the PySide6 system package, use a virtual environment instead:

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

The app uses `dmesg --level=err,crit,alert,emerg`. On systems that restrict unprivileged kernel logs, it reports `NOT AVAILABLE` rather than asking for elevation or pretending the log is clean.

On a confirmed Raspberry Pi 4 Model B, Debian is accepted as a supported operating system. Some Raspberry Pi-specific utilities may still be unavailable on a plain Debian image; those individual checks report `NOT AVAILABLE` with their evidence instead of turning the operating-system result into a warning.

## LDROBOT LD19 with D300 development kit

The Individual Tests window includes **Auto Detect LD19 / D300**, **LD19 / D300 LiDAR**, **ROS 2 LiDAR integration**, and **DISTANCE CHECK (LD19)**. The raw LD19 test is for this physical path:

```
LD19 -> D300 Development Kit -> USB -> Raspberry Pi 4B
```

It enumerates USB/ACM serial ports with pyserial instead of assuming `/dev/ttyUSB0`, opens one candidate at a time at **230400 baud**, and accepts a port only after five consecutive CRC-verified LD19 frames. The ten-second hardware test reopens that verified port and requires real packet evidence: multiple rotations, approximately full angular coverage, valid decoded ranges, and a stable stream. A USB adapter alone is never a PASS.

For a Linux user who cannot open a detected serial device, use the normal Raspberry Pi OS serial group workflow, then log out and back in:

```bash
sudo usermod -aG dialout "$USER"
```

Do not run the application as root. If a ROS 2 driver, serial terminal, or another process owns the port, the raw test reports **PORT BUSY**. Stop that process before the raw test. The optional ROS 2 check releases the application's raw port first and separately validates `/scan` and one `LaserScan` message; its absence does not fail LD19 hardware.

Use **Test All 3 Distances** for one guided test covering 0.5 m, 1.0 m, and 2.0 m. The app prompts before each capture so you can reposition one flat, solid target; all three named results stay in the Diagnostic results table. The Individual Tests window still offers a one-off distance check. Select Cancel to stop the guided sequence; any completed results remain visible.

Typical healthy hardware results include a port such as `/dev/ttyUSB0` or `/dev/ttyACM0`, baud `230400`, a scan rate near 10 Hz (normal supported region about 5-13 Hz), a point rate near 4500 points/sec, increasing angle data through multiple rotations, and populated min/max/median range evidence. Object placement and room size naturally change observed range values, so the test does not demand a 12 m return.

### Test directly from a Windows laptop

The **Test Connected LiDAR** button is available on the main screen even when the app is running on a laptop rather than a Raspberry Pi. Connect the sensor through the D300 development kit with its USB data cable, power the LiDAR so its motor is running, then select that button. The test is read-only: it auto-finds a wired serial port, captures real LD19 frames at `230400` baud for about 10 seconds, and reports CRC, rotations, angular coverage, range, and stream continuity. Bluetooth virtual COM ports are intentionally ignored.

Completed test rows are retained when another test starts, so you can run **Test Connected LiDAR** and then **Test All 3 Distances** without losing the earlier evidence.

If no wired serial port appears, confirm the D300 is connected with a data-capable cable and check Windows Device Manager for a USB Serial Device / CP210x / CH340-style COM port. Close any serial terminal or LiDAR driver that already owns the port, then retry.

## Run automated checks before deployment

```bash
python3 -m unittest discover -s tests -v
python3 -m compileall -q app.py raspberry_pi_tester tests
```

The automated tests validate parsing, safe status handling, warning behavior for historical undervoltage, unsupported model handling, and command-runner behavior. They do **not** simulate physical Pi hardware and cannot replace a real Pi 4B test.

The LD19 software tests additionally validate the documented CRC example, packet parsing, bad CRC/payload rejection, truncated and fragmented reads, garbage resynchronisation, consecutive frames, disconnect/permission/busy handling, and PASS/WARNING/FAIL health decisions. Their generated packets are protocol fixtures only, not a claim of physical sensor validation.

## Reports and logs

- **Save Report** writes matching JSON and plain-text reports to a folder you choose.
- **Open Logs** opens the local log directory. On Raspberry Pi OS this is normally `~/.local/state/pi4b-hardware-tester/tester.log`.
- Reports include explicit evidence and recommendations. No command output is silently interpreted as a hardware pass without a check-specific criterion.
